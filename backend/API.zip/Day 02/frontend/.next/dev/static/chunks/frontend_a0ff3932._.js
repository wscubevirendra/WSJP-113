(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d169e285._.js",
  "static/chunks/9e883_next_dist_compiled_react-dom_33d456f8._.js",
  "static/chunks/9e883_next_dist_compiled_react-server-dom-turbopack_6723cebf._.js",
  "static/chunks/9e883_next_dist_compiled_next-devtools_index_6915c2bc.js",
  "static/chunks/9e883_next_dist_compiled_8f5ebc08._.js",
  "static/chunks/9e883_next_dist_client_21c89b8d._.js",
  "static/chunks/9e883_next_dist_e24ad472._.js",
  "static/chunks/9e883_@swc_helpers_cjs_c26b7a0e._.js"
],
    source: "entry"
});
