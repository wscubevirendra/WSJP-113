const express = require("express");
const mongoose = require("mongoose")
const server = express();
server.use(express.json())


const studentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    age: {
        type: Number,
        default: null,
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    course: {
        type: String,
        default: "web"
    },
    status: {
        type: Boolean,
        default: true
    }
})

const studentModel = mongoose.model("Students", studentSchema);


server.post("/student/create", async (req, res) => {
    try {
        const exist = await student.findOne({ email: req.body.email });
        console.log(exist)
        if (exist) {
            return res.send({
                message: "Try with diffrent email",
                flag: 0
            })
        }

        await studentModel.create({
            name: req.body.name,
            age: req.body.age,
            email: req.body.email,
            course: req.body.course
        })

        res.send({
            message: "Student Data Create",
            flag: 1
        })

    } catch (error) {
        res.send({
            message: "Internal Server Error",
            flag: 0
        })
    }
})

server.get("/student", async (req, res) => {
    try {
        const students = await studentModel.find();
        res.send({
            message: "Data find",
            flag: 1,
            students
        })

    } catch (error) {
        res.send({
            message: "Internal Server Error",
            flag: 0
        })
    }
})

server.delete("/student/delete/:id", async (req, res) => {
    try {
        const id = req.params.id
        const studentExist = await studentModel.findById(id);
        if (!studentExist) {
            res.send({
                message: "Student data not found",
                flag: 0
            })
        }

        await studentModel.deleteOne({ _id: id })
        res.send({
            message: "Data delete succesfully",
            flag: 1
        })

    } catch (error) {
        res.send({
            message: "Internal Server Error",
            flag: 0
        })
    }
})



server.patch("/student/update/:id", async (req, res) => {
    try {
        const id = req.params.id
        const studentExist = await studentModel.findById(id);
        if (!studentExist) {
            res.send({
                message: "Student data not found",
                flag: 0
            })
        }

        await studentModel.updateOne(
            { _id: id },
            {
                $set: {
                    status: !studentExist.status
                }
            }
        )

          res.send({
            message: "Data Update succesfully",
            flag: 1
        })



    } catch (error) {
        res.send({
            message: "Internal Server Error",
            flag: 0
        })
    }
})


mongoose.connect("mongodb://localhost:27017/wsjp113").then(
    () => {
        console.log("DataBase Connect")

        server.listen(
            "5000",
            () => {
                console.log("Server Start PORT number 5000")
            }
        )
    }
).catch(
    () => {
        console.log("DataBase not connect")
    }
)





