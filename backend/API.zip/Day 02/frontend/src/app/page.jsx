import { getStudents } from '@/api-call/studentAPI'
import React from 'react'

export default async function page() {
  const studentJSON = await getStudents();
  const students = studentJSON.students;
  return (
    <div className="max-w-7xl mx-auto">
      <table className="min-w-full bg-white border border-gray-200 rounded-lg">
        <thead className="bg-gray-100">
          <tr>
            <th className="py-3 px-6 text-left text-gray-700 font-medium uppercase">Name</th>
            <th className="py-3 px-6 text-left text-gray-700 font-medium uppercase">Email</th>
            <th className="py-3 px-6 text-left text-gray-700 font-medium uppercase">Age</th>
            <th className="py-3 px-6 text-left text-gray-700 font-medium uppercase">Course Status</th>
          </tr>
        </thead>
        <tbody className="text-gray-600">
          {
            students.map((data) => {
              return (

                <tr key={data._id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-6">{data.name}</td>
                  <td className="py-3 px-6">{data.email}</td>
                  <td className="py-3 px-6">{data.age}</td>
                  <td className="py-3 px-6">
                    <span className="px-3 py-1 rounded-full bg-red-100 text-red-800 text-sm font-semibold">
                      {data.status ? "Active" : "Inactive"}
                    </span>
                  </td>
                </tr>
              )
            })
          }


        </tbody>
      </table>
    </div>

  )
}
