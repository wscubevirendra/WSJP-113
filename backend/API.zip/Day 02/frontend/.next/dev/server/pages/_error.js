var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/9e883_f9d2304b._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/9e883_2f8c5f27._.js")
R.c("server/chunks/ssr/[externals]__e6a4d965._.js")
R.c("server/chunks/ssr/9e883_next_6d50d50f._.js")
R.m("[project]/frontend/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/frontend/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/frontend/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/frontend/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/frontend/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/frontend/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/frontend/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/frontend/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
