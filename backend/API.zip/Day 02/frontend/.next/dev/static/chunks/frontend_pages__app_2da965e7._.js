(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_next_dist_compiled_7638d890._.js",
  "static/chunks/9e883_next_dist_shared_lib_5730557d._.js",
  "static/chunks/9e883_next_dist_client_e93bee36._.js",
  "static/chunks/9e883_next_dist_41c0e04f._.js",
  "static/chunks/9e883_next_app_3f020608.js",
  "static/chunks/[next]_entry_page-loader_ts_c1675e40._.js",
  "static/chunks/9e883_react-dom_3d11c48e._.js",
  "static/chunks/9e883_bb6d2665._.js",
  "static/chunks/[root-of-the-server]__6a99bfdf._.js"
],
    source: "entry"
});
