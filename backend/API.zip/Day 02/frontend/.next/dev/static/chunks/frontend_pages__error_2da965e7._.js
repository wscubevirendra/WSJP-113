(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_next_dist_compiled_7638d890._.js",
  "static/chunks/9e883_next_dist_shared_lib_c2715521._.js",
  "static/chunks/9e883_next_dist_client_e93bee36._.js",
  "static/chunks/9e883_next_dist_8945504d._.js",
  "static/chunks/9e883_next_error_43788141.js",
  "static/chunks/[next]_entry_page-loader_ts_b9ef54ef._.js",
  "static/chunks/9e883_react-dom_3d11c48e._.js",
  "static/chunks/9e883_bb6d2665._.js",
  "static/chunks/[root-of-the-server]__2b803f7d._.js"
],
    source: "entry"
});
